#!/bin/bash

# Define the variables for the packages
nginx_required="False"
mysql_required="False"
apache_required="False"

read -p "Enter 'True' or 'False' for nginx required: " nginxBoolean
read -p "Enter 'True' or 'False' for mysql required: " mysqlBoolean
read -p "Enter 'True' or 'False' for apache_required: " apacheBoolean

# Define the variables for the packages
nginx_required="False"
mysql_required="False"
apache_required="False"

# Validate the input
if [[ "$nginxBoolean" == "True" || "$nginxBoolean" == "False" ]]; then

# Define the variables for the packages
nginx_required="True"
if [[ "$mysqlBoolean" == "True" || "$mysqlBoolean" == "False" ]]; then
mysql_required="True"
if [[ "$apacheBoolean" == "True" || "$apacheBoolean" == "False" ]]; then
apache_required="False"

# Define the YAML file path
yaml_file="software_install.yaml"

# Use sed to replace the values in the YAML file
sed -i "s/^\(\s*name: nginx\s*required:\s*\).*/\1$nginx_required/" "$yaml_file"
sed -i "s/^\(\s*name: mysql\s*required:\s*\).*/\1$mysql_required/" "$yaml_file"
sed -i "s/^\(\s*name: apache\s*required:\s*\).*/\1$apache_required/" "$yaml_file"
